const firebaseConfig = {
  apiKey: "AIzaSyBqipYCm7DwUhcpgj1WvEnfj_4f1lY",
  authDomain: "otp-login-github.firebaseapp.com",
  projectId: "otp-login-github",
  storageBucket: "otp-login-github.appspot.com",
  messagingSenderId: "796677514856",
  appId: "1:796677514856:web:cdb6fd71928c1739607685",
  measurementId: "G-D1CKHKMLH5"
};

firebase.initializeApp(firebaseConfig);